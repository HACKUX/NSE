abstract class StringValidator {
  bool isValid(String value);
}

class NonEmptyStringValidator implements StringValidator {
  @override
  bool isValid(String value) {
    return value.isNotEmpty;
  }
}

class PhoneNumberAndPasswordValidators {
  final String invalidEmailErrorText = "Numéro de téléphone ne peut pas être vide";
  final String invalidPasswordErrorText = "Mot de passe ne peut pas être vide";

  final StringValidator phoneNumberValidator = NonEmptyStringValidator();
  final StringValidator passwordValidator = NonEmptyStringValidator();
}
