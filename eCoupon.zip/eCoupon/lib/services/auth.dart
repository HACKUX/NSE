import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String phoneNumber;
  UserModel({required this.uid, required this.phoneNumber});
}

abstract class AuthBase {
  Stream<UserModel?> get onAuthStateChanged;
  Future<UserModel?> currentUser();
  Future<UserModel?> signInWithPhoneNumberAndPassword(
      String phoneNumber, String password);
  Future<UserModel?> createUserWithPhoneNumberAndPassword(
      String phoneNumber, String password);
  Future<void> signOut();
}

class Auth implements AuthBase {
  final _firebaseAuth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  UserModel? _userFromFirebase(User? user) {
    if (user == null) {
      return null;
    }
    return UserModel(uid: user.uid, phoneNumber: user.phoneNumber!);
  }

  @override
  Stream<UserModel?> get onAuthStateChanged {
    return _firebaseAuth.authStateChanges().map(_userFromFirebase);
  }

  @override
  Future<UserModel?> currentUser() async {
    final user = _firebaseAuth.currentUser;
    return _userFromFirebase(user);
  }

  @override
  Future<UserModel?> signInWithPhoneNumberAndPassword(
      String phoneNumber, String password) async {
    var userDoc = await _firestore.collection('users').doc(phoneNumber).get();
    if (userDoc.exists) {
      var userData = userDoc.data();
      if (userData['password'] == password) {
        return UserModel(uid: userDoc.id, phoneNumber: phoneNumber);
      } else {
        return null; // Gérer le cas où le mot de passe est incorrect
      }
    } else {
      return null; // Gérer le cas où l'utilisateur n'existe pas
    }
  }

  @override
  Future<UserModel?> createUserWithPhoneNumberAndPassword(
      String phoneNumber, String password) async {
    // Créer un nouvel utilisateur dans la base de données Firestore avec le numéro de téléphone et le mot de passe
  }

  @override
  Future<void> signOut() async {
    return await _firebaseAuth.signOut();
  }
}
