import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:ecoupon/common_widgets/custom_alert_dialog.dart';
import 'package:ecoupon/pages/sign_in/phoneNumber_sign_in_model.dart';
import 'package:ecoupon/services/auth.dart';
import 'package:provider/provider.dart';

class PhoneNumberSignInForm extends StatefulWidget {
  PhoneNumberSignInForm({Key? key, required this.model}) : super(key: key);
  final PhoneNumberSignInModel model;

  static Widget create(BuildContext context) {
    final AuthBase auth = Provider.of<AuthBase>(context);
    return ChangeNotifierProvider<PhoneNumberSignInModel>(
      create: (context) => PhoneNumberSignInModel(auth: auth),
      child: Consumer<PhoneNumberSignInModel>(
        builder: (context, model, _) => PhoneNumberSignInForm(
          model: model,
        ),
      ),
    );
  }

  @override
  State<PhoneNumberSignInForm> createState() => _PhoneNumberSignInFormState();
}

class _PhoneNumberSignInFormState extends State<PhoneNumberSignInForm> {
  final TextEditingController? _phoneNumberController = TextEditingController();
  final TextEditingController? _passwordController = TextEditingController();

  final FocusNode _phoneNumberFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  PhoneNumberSignInModel get model => widget.model;

  Future<void> _submit() async {
    try {
      await model.submit();
    } on FirebaseException catch (e) {
      CustomAlertDialog(
        title: "Connexion impossible",
        content: e.message!,
        defaultActionText: "OK",
      ).show(context);
    }
  }

  void _toogleFormType() {
    model.toggleFormType();
    _phoneNumberController!.clear();
    _passwordController!.clear();
  }

  void _phoneNumberEditingComplete() {
    final newFocus = model.phoneNumberValidator.isValid(model.phoneNumber)
        ? _passwordFocusNode
        : _phoneNumberFocusNode;
    FocusScope.of(context).requestFocus(newFocus);
  }

  List<Widget> _buildChildren() {
    return [
      _buildHeader(),
      const SizedBox(
        height: 20.0,
      ),
      _buildPhoneNumberTextField(),
      const SizedBox(
        height: 15.0,
      ),
      _buildPasswordTextField(),
      const SizedBox(
        height: 15.0,
      ),
      _buildFormActions(),
    ];
  }

  Widget _buildHeader() {
    return Text(
      model.headerText,
      style: Theme.of(context).textTheme.headline2,
    );
  }

  Widget _buildPhoneNumberTextField() {
    return TextField(
      autocorrect: false,
      keyboardType: TextInputType.phone,
      textInputAction: TextInputAction.next,
      controller: _phoneNumberController,
      decoration: InputDecoration(
          labelText: "Numéro de téléphone",
          hintText: "+243XXXXXXXXXX",
          border: OutlineInputBorder(),
          icon: Icon(Icons.phone),
          errorText: model.phoneNumberErrorText,
          enabled: model.isLoading == false),
      focusNode: _phoneNumberFocusNode,
      onEditingComplete: () => _phoneNumberEditingComplete(),
      onChanged: model.updatePhoneNumber,
    );
  }

  Widget _buildPasswordTextField() {
    return TextField(
      controller: _passwordController,
      obscureText: true,
      decoration: InputDecoration(
          labelText: "Mot de passe",
          border: OutlineInputBorder(),
          icon: Icon(Icons.lock),
          errorText: model.passwordErrorText,
          enabled: model.isLoading == false),
      textInputAction: TextInputAction.done,
      focusNode: _passwordFocusNode,
      onEditingComplete: _submit,
      onChanged: model.updatePassword,
    );
  }

  Widget _buildFormActions() {
    if (model.isLoading) {
      return const CircularProgressIndicator();
    }
    return Column(
      children: [
        ElevatedButton(
          onPressed: model.canSubmit ? _submit : null,
          child: Text(
            model.primaryButtonText,
            style: Theme.of(context)
                .textTheme
                .bodyText1!
                .copyWith(color: Colors.black),
          ),
          style: ElevatedButton.styleFrom(
              primary: Colors.deepOrange[200],
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10.0)))),
        ),
        TextButton(
            onPressed: !model.isLoading ? _toogleFormType : null,
            child: Text(
              model.secondaryButtonText,
            ))
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Center(
        child: SingleChildScrollView(
          child: Column(
            children: _buildChildren(),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _phoneNumberController!.dispose();
    _passwordController!.dispose();
    _phoneNumberFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }
}
