import 'package:flutter/material.dart';
import 'package:ecoupon/services/auth.dart';
import 'package:ecoupon/utils/validators.dart';

enum PhoneNumberSignInFormType { signIn, register }

class PhoneNumberSignInModel with PhoneNumberAndPasswordValidators, ChangeNotifier {
  PhoneNumberSignInModel(
      {this.phoneNumber = "",
      this.password = "",
      this.formType = PhoneNumberSignInFormType.signIn,
      this.isLoading = false,
      this.submitted = false,
      required this.auth});

  String phoneNumber;
  String password;
  PhoneNumberSignInFormType formType;
  bool isLoading;
  bool submitted;
  final AuthBase auth;

  void updateWith(
      {String? phoneNumber,
      String? password,
      PhoneNumberSignInFormType? formType,
      bool? isLoading,
      bool? submitted}) {
    this.phoneNumber = phoneNumber ?? this.phoneNumber;
    this.password = password ?? this.password;
    this.formType = formType ?? this.formType;
    this.isLoading = isLoading ?? this.isLoading;
    this.submitted = submitted ?? this.submitted;
    notifyListeners();
  }

  Future<void> submit() async {
    updateWith(submitted: true, isLoading: true);
    try {
      if (formType == PhoneNumberSignInFormType.signIn) {
        await auth.signInWithPhoneNumberAndPassword(phoneNumber, password);
      } else {
        await auth.createUserWithPhoneNumberAndPassword(phoneNumber, password);
      }
    } catch (e) {
      updateWith(isLoading: false);
      rethrow;
    }
  }

  String get headerText {
    return formType == PhoneNumberSignInFormType.signIn ? "Connexion" : "Inscription";
  }

  String get primaryButtonText {
    return formType == PhoneNumberSignInFormType.signIn
        ? "Se connecter"
        : "Créer un compte";
  }

  String get secondaryButtonText {
    return formType == PhoneNumberSignInFormType.signIn
        ? "Avez-vous besoin d'un compte ? Inscrivez-vous"
        : "Avez-vous un compte ? Connectez-vous";
  }

  bool get canSubmit {
    return phoneNumberValidator.isValid(phoneNumber) &&
        passwordValidator.isValid(password) &&
        !isLoading;
  }

  String? get passwordErrorText {
    bool showErrorText = submitted && !passwordValidator.isValid(password);
    return showErrorText ? invalidPasswordErrorText : null;
  }

  String? get phoneNumberErrorText {
    bool showErrorText = submitted && !phoneNumberValidator.isValid(phoneNumber);
    return showErrorText ? invalidEmailErrorText : null;
  }

  void updatePhoneNumber(String phoneNumber) => updateWith(phoneNumber: phoneNumber);
  void updatePassword(String password) => updateWith(password: password);

  void toggleFormType() {
    final formType = this.formType == PhoneNumberSignInFormType.signIn
        ? PhoneNumberSignInFormType.register
        : PhoneNumberSignInFormType.signIn;

    updateWith(
      phoneNumber: "",
      password: "",
      formType: formType,
      submitted: false,
      isLoading: false,
    );
  }
}
