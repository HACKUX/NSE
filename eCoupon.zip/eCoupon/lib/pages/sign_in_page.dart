import 'package:flutter/material.dart';
import 'package:ecoupon/pages/sign_in/phoneNumber_sign_in_form.dart';

class SignInPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "eCoupon",
          style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        elevation: 2.0,
        backgroundColor: Colors.blue[400],
      ),
      body: PhoneNumberSignInForm.create(context),
    );
  }
}
