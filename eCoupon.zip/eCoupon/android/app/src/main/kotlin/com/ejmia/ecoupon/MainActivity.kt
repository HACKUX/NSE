package com.ejmia.ecoupon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
